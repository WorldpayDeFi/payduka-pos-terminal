# ⬡ PayDuka Terminal

> Offline-first blockchain point-of-sale for African merchants — built on Polygon, PowerSync & Supabase.

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Built on Polygon](https://img.shields.io/badge/Blockchain-Polygon-8247e5)](https://polygon.technology)
[![Powered by PowerSync](https://img.shields.io/badge/Sync-PowerSync-blue)](https://powersync.com)
[![Backend: Supabase](https://img.shields.io/badge/Backend-Supabase-3ecf8e)](https://supabase.com)

---

## What is PayDuka Terminal?

PayDuka Terminal is the merchant-facing PoS application of the [PayDuka](https://payduka.xyz) ecosystem. It allows merchants — from informal vendors to supermarket chains — to process payments via **cash, card, or PDuka token** with full offline resilience.

### Key Features

- **Offline-first** — transactions queue locally via PowerSync, sync automatically when online
- **Multi-payment** — cash, card interchange, and PDuka token (ERC-20 on Polygon)
- **Deflationary monetary policy** — 0.5% burn + 2% treasury skim per PDuka transaction
- **Cashier PIN auth** — role-based access (cashier / manager)
- **Conflict-safe sync** — three strategies baked in from day one
- **Real-time dashboard** — sales, low stock alerts, transaction history

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite |
| Offline Sync | PowerSync (React SDK) |
| Backend | Supabase (Postgres + Edge Functions) |
| Blockchain | Polygon Mainnet + ethers.js v6 |
| Token | PDuka ERC-20 (21B fixed supply) |
| Settlement | ZARP stablecoin |
| Deploy | Vercel |

---

## Conflict Resolution Strategy

PayDuka Terminal implements three PowerSync conflict resolution strategies:

| Strategy | Where Used | How |
|---|---|---|
| **Strategy 7** — Cumulative Ops | Inventory | Deltas applied server-side, never replace absolute counts |
| **Strategy 4** — Business Rules | Sales | Confirmed sales are immutable; status cannot revert |
| **Strategy 5** — Conflict Log | Edge cases | Unresolvable conflicts synced back for manager review |

---

## Getting Started

### 1. Clone the repo

```bash
git clone https://github.com/WorldpayDeFi/payduka-terminal.git
cd payduka-terminal
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up environment variables

```bash
cp .env.example .env
# Fill in your Supabase, PowerSync, and Polygon values
```

### 4. Set up Supabase database

Run `supabase/schema.sql` in your Supabase SQL editor.

### 5. Deploy the Edge Function

```bash
supabase functions deploy sync-upload
```

### 6. Configure PowerSync

Upload `sync-rules.yaml` to your PowerSync dashboard.

### 7. Run locally

```bash
npm run dev
```

---

## Payment Flow

```
Customer pays PDuka
       ↓
Polygon RPC confirms tx
       ↓
Smart contract burns 0.5% + skims 2% treasury
       ↓
97.5% auto-converts to ZARP
       ↓
Merchant wallet receives ZARP
```

For card payments, PayDuka reimburses the ~1.68% interchange fee via a 1% PDuka reward to the customer.

---

## Project Structure

```
src/
├── App.jsx                  # Root + nav + session
├── screens/
│   ├── PinAuth.jsx          # Cashier PIN login
│   ├── Terminal.jsx         # Main PoS screen
│   └── Dashboard.jsx        # Sales + stock dashboard
├── components/
│   ├── ProductSearch.jsx    # Search + barcode
│   ├── Cart.jsx             # Cart management
│   ├── PaymentModal.jsx     # Cash / card / PDuka checkout
│   ├── SyncStatus.jsx       # Online/offline indicator
│   └── ConflictResolver.jsx # Strategy 5 conflict UI
└── lib/
    ├── powersync/
    │   ├── db.js            # PowerSync DB + schema
    │   └── SupabaseConnector.js
    └── polygon/
        └── index.js         # Wallet + PDuka payment logic
```

---

## Roadmap

- [ ] Barcode scanner integration (camera + USB)
- [ ] Receipt printer support
- [ ] Manager dashboard (stock adjustments, cashier management)
- [ ] PDuka ↔ ZARP Chainlink oracle (live rate)
- [ ] Multi-store / franchise support
- [ ] Claude AI merchant assistant tab

---

## Built By

**PayDuka Ltd** — Ermelo, South Africa  
Founder & CEO: X.G. Sikhosana  
Website: [payduka.xyz](https://payduka.xyz)  
Contact: [info@payduka.xyz](mailto:info@payduka.xyz)

> Built entirely from a mobile phone. 🤙

---

## License

MIT — see [LICENSE](LICENSE)
