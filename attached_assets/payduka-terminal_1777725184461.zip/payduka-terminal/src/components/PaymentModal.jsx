import { useState } from "react";
import { zarToPduka, connectWallet, processPdukaPayment, calculateMonetaryPolicy } from "../lib/polygon";
import "./PaymentModal.css";

const MERCHANT_WALLET = import.meta.env.VITE_MERCHANT_WALLET;

export default function PaymentModal({ total, onConfirm, onClose }) {
  const [method, setMethod] = useState("cash");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [pdukaCost, setPdukaCost] = useState(null);
  const [walletAddr, setWalletAddr] = useState("");

  const policy = calculateMonetaryPolicy(total);

  const loadPdukaRate = async () => {
    const cost = await zarToPduka(total);
    setPdukaCost(cost.toFixed(4));
  };

  const handleMethodChange = (m) => {
    setMethod(m);
    setError("");
    if (m === "pduka") loadPdukaRate();
  };

  const handleConfirm = async () => {
    setLoading(true);
    setError("");
    try {
      let txHash = "";

      if (method === "pduka") {
        const addr = await connectWallet();
        setWalletAddr(addr);
        const result = await processPdukaPayment({
          toAddress: MERCHANT_WALLET,
          amountPduka: parseFloat(pdukaCost),
        });
        if (result.status !== "confirmed") throw new Error("Transaction failed");
        txHash = result.txHash;
      }

      await onConfirm({ paymentMethod: method, walletAddress: walletAddr, txHash });
    } catch (err) {
      setError(err.message || "Payment failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <span className="modal-title">Checkout</span>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        <div className="modal-amount">
          <span className="modal-label">Total Due</span>
          <span className="modal-total">R{total.toFixed(2)}</span>
        </div>

        {/* Payment method selector */}
        <div className="method-tabs">
          {["cash", "card", "pduka"].map((m) => (
            <button
              key={m}
              className={`method-tab ${method === m ? "active" : ""}`}
              onClick={() => handleMethodChange(m)}
            >
              {m === "cash" && "💵 Cash"}
              {m === "card" && "💳 Card"}
              {m === "pduka" && "⬡ PDuka"}
            </button>
          ))}
        </div>

        {/* Method details */}
        <div className="method-details">
          {method === "cash" && (
            <div className="method-info">
              <p>Collect <strong>R{total.toFixed(2)}</strong> cash from customer.</p>
              <p className="method-note">Transaction recorded locally, synced when online.</p>
            </div>
          )}

          {method === "card" && (
            <div className="method-info">
              <p>Process card payment via terminal.</p>
              <p className="method-note">
                Interchange fee: ~1.68% · PayDuka reimbursement: 1% PDuka reward to customer
              </p>
              <div className="policy-row">
                <span>Merchant receives (ZARP)</span>
                <span>R{policy.merchantZarp.toFixed(2)}</span>
              </div>
            </div>
          )}

          {method === "pduka" && (
            <div className="method-info">
              <div className="pduka-rate">
                <span className="pduka-label">PDuka required</span>
                <span className="pduka-value">
                  {pdukaCost ? `${pdukaCost} PDuka` : "Loading…"}
                </span>
              </div>
              <div className="policy-breakdown">
                <div className="policy-row">
                  <span>Merchant (ZARP)</span>
                  <span>R{policy.merchantZarp.toFixed(2)}</span>
                </div>
                <div className="policy-row">
                  <span>Treasury skim (2%)</span>
                  <span>R{policy.treasurySkim.toFixed(2)}</span>
                </div>
                <div className="policy-row burn-row">
                  <span>Burn (0.5%)</span>
                  <span>R{policy.burnAmount.toFixed(2)}</span>
                </div>
              </div>
              <p className="method-note">Customer connects wallet and approves transaction on Polygon.</p>
            </div>
          )}
        </div>

        {error && <div className="modal-error">{error}</div>}

        <div className="modal-actions">
          <button className="btn btn-ghost" onClick={onClose} disabled={loading}>
            Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={handleConfirm}
            disabled={loading || (method === "pduka" && !pdukaCost)}
          >
            {loading ? "Processing…" : `Confirm ${method === "pduka" ? "on Polygon" : "Payment"}`}
          </button>
        </div>
      </div>
    </div>
  );
}
