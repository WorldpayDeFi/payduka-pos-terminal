import "./Logo.css";

export default function Logo({ size = "md", showText = true, animate = false }) {
  const sizes = {
    sm: 28,
    md: 38,
    lg: 56,
    xl: 80,
  };

  const px = sizes[size] || sizes.md;

  return (
    <div className={`logo-wrap logo-${size} ${animate ? "logo-animate" : ""}`}>
      <img
        src="/logo.png"
        alt="PayDuka"
        className="logo-img"
        width={px}
        height={px}
        draggable={false}
      />
      {showText && (
        <div className="logo-text">
          <span className="logo-name">PayDuka</span>
          <span className="logo-tag">Terminal</span>
        </div>
      )}
    </div>
  );
}
