import { useState } from "react";
import { usePowerSyncQuery } from "@powersync/react";
import "./ProductSearch.css";

export default function ProductSearch({ onAdd }) {
  const [query, setQuery] = useState("");

  const { data: products } = usePowerSyncQuery(
    `SELECT p.*, COALESCE(i.quantity, 0) as stock
     FROM products p
     LEFT JOIN inventory i ON i.product_id = p.id
     WHERE p.name LIKE ? OR p.barcode LIKE ?
     ORDER BY p.name ASC
     LIMIT 40`,
    [`%${query}%`, `%${query}%`]
  );

  return (
    <div className="product-search">
      <div className="search-bar">
        <span className="search-icon">⌕</span>
        <input
          className="input search-input"
          placeholder="Search product or scan barcode…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
        />
        {query && (
          <button className="search-clear" onClick={() => setQuery("")}>✕</button>
        )}
      </div>

      <div className="product-grid">
        {products?.length === 0 && (
          <div className="empty-state">No products found</div>
        )}
        {products?.map((p) => (
          <button
            key={p.id}
            className={`product-card ${p.stock <= 0 ? "out-of-stock" : ""}`}
            onClick={() => p.stock > 0 && onAdd(p)}
            disabled={p.stock <= 0}
          >
            <div className="product-name">{p.name}</div>
            <div className="product-meta">
              <span className="product-price">R{parseFloat(p.price).toFixed(2)}</span>
              <span className={`product-stock ${p.stock <= 5 ? "low" : ""}`}>
                {p.stock <= 0 ? "Out" : `${p.stock} left`}
              </span>
            </div>
            {p.category && (
              <span className="product-cat">{p.category}</span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
