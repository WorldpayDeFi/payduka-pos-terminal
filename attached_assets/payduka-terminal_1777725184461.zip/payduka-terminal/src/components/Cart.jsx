import "./Cart.css";

export default function Cart({ items, onUpdateQty, onClear, total }) {
  return (
    <div className="cart">
      <div className="cart-header">
        <span className="cart-title">Cart</span>
        <span className="cart-count">{items.length} item{items.length !== 1 ? "s" : ""}</span>
        {items.length > 0 && (
          <button className="cart-clear btn btn-ghost" onClick={onClear}>Clear</button>
        )}
      </div>

      <div className="cart-items">
        {items.length === 0 && (
          <div className="cart-empty">
            <span>No items yet</span>
            <p>Search and tap products to add them</p>
          </div>
        )}
        {items.map(({ product, quantity }) => (
          <div key={product.id} className="cart-item">
            <div className="cart-item-info">
              <span className="cart-item-name">{product.name}</span>
              <span className="cart-item-unit">R{parseFloat(product.price).toFixed(2)} each</span>
            </div>
            <div className="cart-item-controls">
              <button
                className="qty-btn"
                onClick={() => onUpdateQty(product.id, quantity - 1)}
              >−</button>
              <span className="qty-value">{quantity}</span>
              <button
                className="qty-btn"
                onClick={() => onUpdateQty(product.id, quantity + 1)}
              >+</button>
            </div>
            <span className="cart-item-total">
              R{(product.price * quantity).toFixed(2)}
            </span>
          </div>
        ))}
      </div>

      <div className="cart-footer">
        <div className="cart-total-row">
          <span>Subtotal</span>
          <span>R{total.toFixed(2)}</span>
        </div>
        <div className="cart-total-row cart-total-main">
          <span>Total</span>
          <span className="total-amount">R{total.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
