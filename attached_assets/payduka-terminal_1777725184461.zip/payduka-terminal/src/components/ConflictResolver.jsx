import { usePowerSyncQuery, usePowerSync } from "@powersync/react";
import "./ConflictResolver.css";

export default function ConflictResolver() {
  const powerSync = usePowerSync();

  const { data: conflicts } = usePowerSyncQuery(
    "SELECT * FROM write_conflicts WHERE resolved = 0 ORDER BY created_at DESC"
  );

  if (!conflicts || conflicts.length === 0) return null;

  const handleResolve = async (conflictId) => {
    await powerSync.execute(
      "UPDATE write_conflicts SET resolved = 1 WHERE id = ?",
      [conflictId]
    );
  };

  return (
    <div className="conflict-bar">
      <span className="conflict-icon">⚠</span>
      <span className="conflict-msg">
        {conflicts.length} unresolved sync conflict{conflicts.length > 1 ? "s" : ""}
      </span>
      <div className="conflict-list">
        {conflicts.map((c) => (
          <div key={c.id} className="conflict-item">
            <span className="conflict-table">{c.table_name}</span>
            <span className="conflict-type">{c.conflict_type}</span>
            <button
              className="btn btn-ghost conflict-resolve"
              onClick={() => handleResolve(c.id)}
            >
              Dismiss
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
