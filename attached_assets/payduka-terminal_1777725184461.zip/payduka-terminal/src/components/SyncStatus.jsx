import { usePowerSyncStatus } from "@powersync/react";

export default function SyncStatus() {
  const status = usePowerSyncStatus();

  const isOnline  = status?.connected;
  const isSyncing = status?.dataFlowStatus?.uploading || status?.dataFlowStatus?.downloading;

  const label = isSyncing ? "Syncing…" : isOnline ? "Online" : "Offline";
  const dot   = isSyncing ? "syncing"  : isOnline ? "online"  : "offline";

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
      <span className={`status-dot ${dot}`} />
      <span style={{ fontSize: 12, color: "var(--text-dim)" }}>{label}</span>
    </div>
  );
}
