import { useState } from "react";
import { usePowerSyncQuery } from "@powersync/react";
import Logo from "../components/Logo";
import "./PinAuth.css";

// Simple PIN hash (use bcrypt in production via backend)
async function hashPin(pin) {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(pin)
  );
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export default function PinAuth({ onAuth }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: cashiers } = usePowerSyncQuery(
    "SELECT * FROM cashiers WHERE active = 1"
  );

  const handleKey = (key) => {
    if (pin.length < 6) setPin((p) => p + key);
  };

  const handleBackspace = () => setPin((p) => p.slice(0, -1));

  const handleSubmit = async () => {
    if (pin.length < 4) return;
    setLoading(true);
    setError("");
    try {
      const hash = await hashPin(pin);
      const match = cashiers?.find((c) => c.pin_hash === hash);
      if (match) {
        onAuth({ cashierId: match.id, name: match.name, role: match.role });
      } else {
        setError("Invalid PIN. Try again.");
        setPin("");
      }
    } catch {
      setError("Auth error. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const dots = Array.from({ length: 6 }, (_, i) => i < pin.length);

  return (
    <div className="pin-screen">
      <div className="pin-card">
        <div className="pin-header">
          <Logo size="xl" showText={false} animate={true} />
          <h1>PayDuka Terminal</h1>
          <p>Enter your cashier PIN to continue</p>
        </div>

        <div className="pin-dots">
          {dots.map((filled, i) => (
            <div key={i} className={`pin-dot ${filled ? "filled" : ""}`} />
          ))}
        </div>

        {error && <div className="pin-error">{error}</div>}

        <div className="pin-grid">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
            <button key={n} className="pin-key" onClick={() => handleKey(String(n))}>
              {n}
            </button>
          ))}
          <button className="pin-key pin-key-ghost" onClick={handleBackspace}>⌫</button>
          <button className="pin-key" onClick={() => handleKey("0")}>0</button>
          <button
            className="pin-key pin-key-submit"
            onClick={handleSubmit}
            disabled={pin.length < 4 || loading}
          >
            {loading ? "…" : "↵"}
          </button>
        </div>
      </div>
    </div>
  );
}
