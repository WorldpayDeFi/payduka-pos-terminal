import { useState, useCallback } from "react";
import { usePowerSyncQuery, usePowerSync } from "@powersync/react";
import { v4 as uuid } from "uuid";
import { zarToPduka, processPdukaPayment, calculateMonetaryPolicy, connectWallet } from "../lib/polygon";
import ProductSearch from "../components/ProductSearch";
import Cart from "../components/Cart";
import PaymentModal from "../components/PaymentModal";
import SyncStatus from "../components/SyncStatus";
import "./Terminal.css";

export default function Terminal({ session }) {
  const powerSync = usePowerSync();
  const [cart, setCart] = useState([]); // [{ product, quantity }]
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [lastSale, setLastSale] = useState(null);

  // ── Cart operations ──────────────────────────────────
  const addToCart = useCallback((product) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id
            ? { ...i, quantity: i.quantity + 1 }
            : i
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }, []);

  const updateQty = useCallback((productId, qty) => {
    if (qty <= 0) {
      setCart((prev) => prev.filter((i) => i.product.id !== productId));
    } else {
      setCart((prev) =>
        prev.map((i) =>
          i.product.id === productId ? { ...i, quantity: qty } : i
        )
      );
    }
  }, []);

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce(
    (sum, i) => sum + i.product.price * i.quantity,
    0
  );

  // ── Checkout ─────────────────────────────────────────
  const handleCheckout = async ({ paymentMethod, walletAddress, txHash }) => {
    const saleId = uuid();
    const now = new Date().toISOString();
    const policy = calculateMonetaryPolicy(cartTotal);
    const pdukaCost = await zarToPduka(cartTotal);

    try {
      await powerSync.writeTransaction(async (tx) => {
        // 1. Create sale (Strategy 4: once confirmed, immutable)
        await tx.execute(
          `INSERT INTO sales (id, cashier_id, total_zar, total_pduka, payment_method, status, tx_hash, created_at)
           VALUES (?, ?, ?, ?, ?, 'confirmed', ?, ?)`,
          [saleId, session.cashierId, cartTotal, pdukaCost, paymentMethod, txHash || "", now]
        );

        // 2. Create sale items
        for (const item of cart) {
          await tx.execute(
            `INSERT INTO sale_items (id, sale_id, product_id, product_name, quantity, unit_price, line_total)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
              uuid(), saleId,
              item.product.id, item.product.name,
              item.quantity, item.product.price,
              item.product.price * item.quantity,
            ]
          );

          // 3. Strategy 7: Apply inventory delta (not absolute value)
          await tx.execute(
            `UPDATE inventory SET quantity = quantity - ?, last_updated = ?
             WHERE product_id = ?`,
            [item.quantity, now, item.product.id]
          );

          // 4. Log delta for audit (insertOnly table)
          await tx.execute(
            `INSERT INTO inventory_deltas (id, product_id, delta, reason, sale_id, cashier_id, created_at)
             VALUES (?, ?, ?, 'sale', ?, ?, ?)`,
            [uuid(), item.product.id, -item.quantity, saleId, session.cashierId, now]
          );
        }
      });

      setLastSale({ saleId, total: cartTotal, policy, paymentMethod, txHash });
      clearCart();
      setPaymentOpen(false);
    } catch (err) {
      console.error("[PayDuka] Checkout error:", err);
      throw err;
    }
  };

  return (
    <div className="terminal">
      {/* Left: Product search */}
      <div className="terminal-left">
        <div className="terminal-topbar">
          <SyncStatus />
          <span className="terminal-cashier">
            Cashier: <strong>{session.name}</strong>
          </span>
        </div>
        <ProductSearch onAdd={addToCart} />
      </div>

      {/* Right: Cart + Checkout */}
      <div className="terminal-right">
        <Cart
          items={cart}
          onUpdateQty={updateQty}
          onClear={clearCart}
          total={cartTotal}
        />

        {lastSale && (
          <div className="sale-receipt">
            <div className="receipt-icon">✓</div>
            <div>
              <div className="receipt-title">Sale Confirmed</div>
              <div className="receipt-sub">
                R{lastSale.total.toFixed(2)} · {lastSale.paymentMethod.toUpperCase()}
              </div>
              {lastSale.txHash && (
                <a
                  className="receipt-hash"
                  href={`https://polygonscan.com/tx/${lastSale.txHash}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  {lastSale.txHash.slice(0, 12)}…
                </a>
              )}
            </div>
            <button className="btn btn-ghost" onClick={() => setLastSale(null)}>✕</button>
          </div>
        )}

        <button
          className="btn btn-primary checkout-btn"
          disabled={cart.length === 0}
          onClick={() => setPaymentOpen(true)}
        >
          Checkout · R{cartTotal.toFixed(2)}
        </button>
      </div>

      {paymentOpen && (
        <PaymentModal
          total={cartTotal}
          onConfirm={handleCheckout}
          onClose={() => setPaymentOpen(false)}
        />
      )}
    </div>
  );
}
