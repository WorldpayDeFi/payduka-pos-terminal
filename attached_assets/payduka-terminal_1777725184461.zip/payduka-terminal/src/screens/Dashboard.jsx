import { usePowerSyncQuery } from "@powersync/react";
import "./Dashboard.css";

export default function Dashboard({ session }) {
  const { data: recentSales } = usePowerSyncQuery(
    `SELECT s.*, c.name as cashier_name
     FROM sales s
     LEFT JOIN cashiers c ON c.id = s.cashier_id
     ORDER BY s.created_at DESC
     LIMIT 20`
  );

  const { data: lowStock } = usePowerSyncQuery(
    `SELECT p.name, i.quantity
     FROM inventory i
     JOIN products p ON p.id = i.product_id
     WHERE i.quantity <= 5
     ORDER BY i.quantity ASC`
  );

  const todayTotal = recentSales
    ?.filter((s) => s.created_at?.startsWith(new Date().toISOString().slice(0, 10)))
    ?.reduce((sum, s) => sum + s.total_zar, 0) || 0;

  return (
    <div className="dashboard">
      {/* Stats row */}
      <div className="stats-row">
        <div className="stat-card">
          <span className="stat-label">Today's Sales</span>
          <span className="stat-value">R{todayTotal.toFixed(2)}</span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Transactions</span>
          <span className="stat-value">{recentSales?.length || 0}</span>
        </div>
        <div className="stat-card stat-warn">
          <span className="stat-label">Low Stock Items</span>
          <span className="stat-value">{lowStock?.length || 0}</span>
        </div>
      </div>

      <div className="dashboard-grid">
        {/* Recent sales */}
        <div className="card">
          <div className="card-title">Recent Sales</div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Cashier</th>
                  <th>Method</th>
                  <th>Total</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentSales?.map((s) => (
                  <tr key={s.id}>
                    <td>{new Date(s.created_at).toLocaleTimeString()}</td>
                    <td>{s.cashier_name || "—"}</td>
                    <td>
                      <span className={`badge badge-${s.payment_method === "pduka" ? "gold" : "neutral"}`}>
                        {s.payment_method}
                      </span>
                    </td>
                    <td className="td-amount">R{parseFloat(s.total_zar).toFixed(2)}</td>
                    <td>
                      <span className={`badge badge-${s.status === "confirmed" ? "accent" : "danger"}`}>
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low stock */}
        <div className="card">
          <div className="card-title">Low Stock Alert</div>
          {lowStock?.length === 0 ? (
            <p className="empty-msg">All products well stocked ✓</p>
          ) : (
            <div className="stock-list">
              {lowStock?.map((item) => (
                <div key={item.name} className="stock-row">
                  <span className="stock-name">{item.name}</span>
                  <span className={`stock-qty ${item.quantity === 0 ? "out" : "low"}`}>
                    {item.quantity === 0 ? "OUT OF STOCK" : `${item.quantity} left`}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
