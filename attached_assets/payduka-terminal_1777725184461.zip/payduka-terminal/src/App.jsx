import { useState } from "react";
import { PowerSyncContext } from "@powersync/react";
import { db } from "./lib/powersync/db";
import PinAuth from "./screens/PinAuth";
import Terminal from "./screens/Terminal";
import Dashboard from "./screens/Dashboard";
import ConflictResolver from "./components/ConflictResolver";
import Logo from "./components/Logo";
import "./App.css";

export default function App() {
  const [session, setSession] = useState(null); // { cashierId, name, role }
  const [view, setView] = useState("pos"); // 'pos' | 'dashboard'

  return (
    <PowerSyncContext.Provider value={db}>
      <div className="app-root">
        {!session ? (
          <PinAuth onAuth={setSession} />
        ) : (
          <>
            <nav className="app-nav">
              <div className="nav-brand">
                <Logo size="sm" showText={true} />
              </div>
              <div className="nav-center">
                <button
                  className={`nav-btn ${view === "pos" ? "active" : ""}`}
                  onClick={() => setView("pos")}
                >
                  POS
                </button>
                <button
                  className={`nav-btn ${view === "dashboard" ? "active" : ""}`}
                  onClick={() => setView("dashboard")}
                >
                  Dashboard
                </button>
              </div>
              <div className="nav-right">
                <span className="cashier-pill">
                  {session.name} · {session.role}
                </span>
                <button className="nav-btn" onClick={() => setSession(null)}>
                  Lock
                </button>
              </div>
            </nav>

            <ConflictResolver />

            <main className="app-main">
              {view === "pos" ? (
                <Terminal session={session} />
              ) : (
                <Dashboard session={session} />
              )}
            </main>
          </>
        )}
      </div>
    </PowerSyncContext.Provider>
  );
}
