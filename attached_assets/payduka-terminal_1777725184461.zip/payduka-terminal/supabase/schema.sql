-- PayDuka Terminal — Supabase Database Schema
-- Run this in your Supabase SQL editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Products ────────────────────────────────────────────
CREATE TABLE products (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT NOT NULL,
  barcode     TEXT UNIQUE,
  price       DECIMAL(10,2) NOT NULL,
  category    TEXT,
  image_url   TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Inventory (cumulative model — Strategy 7) ───────────
CREATE TABLE inventory (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id   UUID REFERENCES products(id) ON DELETE CASCADE,
  quantity     INTEGER NOT NULL DEFAULT 0,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(product_id)
);

-- ── Cashiers ────────────────────────────────────────────
CREATE TABLE cashiers (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name      TEXT NOT NULL,
  pin_hash  TEXT NOT NULL,
  role      TEXT NOT NULL DEFAULT 'cashier', -- 'cashier' | 'manager'
  active    BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── Sales (immutable once confirmed — Strategy 4) ───────
CREATE TABLE sales (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cashier_id      UUID REFERENCES cashiers(id),
  total_zar       DECIMAL(10,2) NOT NULL,
  total_pduka     DECIMAL(18,8),
  payment_method  TEXT NOT NULL, -- 'pduka' | 'card' | 'cash'
  status          TEXT NOT NULL DEFAULT 'confirmed', -- 'pending' | 'confirmed' | 'voided'
  tx_hash         TEXT,          -- Polygon transaction hash
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Prevent status going backwards (Strategy 4)
CREATE OR REPLACE FUNCTION enforce_sale_status()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = 'confirmed' AND NEW.status = 'pending' THEN
    RAISE EXCEPTION 'Cannot revert a confirmed sale to pending';
  END IF;
  IF OLD.status = 'voided' THEN
    RAISE EXCEPTION 'Cannot modify a voided sale';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sale_status_guard
  BEFORE UPDATE ON sales
  FOR EACH ROW EXECUTE FUNCTION enforce_sale_status();

-- ── Sale Items ───────────────────────────────────────────
CREATE TABLE sale_items (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sale_id       UUID REFERENCES sales(id) ON DELETE CASCADE,
  product_id    UUID REFERENCES products(id),
  product_name  TEXT NOT NULL,
  quantity      INTEGER NOT NULL,
  unit_price    DECIMAL(10,2) NOT NULL,
  line_total    DECIMAL(10,2) NOT NULL
);

-- ── Inventory Deltas (Strategy 7 audit log) ─────────────
CREATE TABLE inventory_deltas (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id  UUID REFERENCES products(id),
  delta       INTEGER NOT NULL,  -- negative = sale, positive = restock
  reason      TEXT NOT NULL,     -- 'sale' | 'restock' | 'adjustment'
  sale_id     UUID REFERENCES sales(id),
  cashier_id  UUID REFERENCES cashiers(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Write Conflicts (Strategy 5) ────────────────────────
CREATE TABLE write_conflicts (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  table_name     TEXT NOT NULL,
  row_id         UUID,
  conflict_type  TEXT NOT NULL,
  client_data    JSONB,
  server_data    JSONB,
  resolved       BOOLEAN DEFAULT FALSE,
  cashier_id     UUID REFERENCES cashiers(id),
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── Apply inventory delta (Strategy 7 server function) ──
CREATE OR REPLACE FUNCTION apply_inventory_delta(
  p_product_id UUID,
  p_delta      INTEGER
) RETURNS VOID AS $$
BEGIN
  INSERT INTO inventory (product_id, quantity, last_updated)
  VALUES (p_product_id, GREATEST(0, p_delta), NOW())
  ON CONFLICT (product_id) DO UPDATE
    SET quantity     = GREATEST(0, inventory.quantity + p_delta),
        last_updated = NOW();
END;
$$ LANGUAGE plpgsql;

-- ── Enable Row Level Security ────────────────────────────
ALTER TABLE products         ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory        ENABLE ROW LEVEL SECURITY;
ALTER TABLE cashiers         ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales            ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items       ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_deltas ENABLE ROW LEVEL SECURITY;
ALTER TABLE write_conflicts  ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users (terminals) full access
CREATE POLICY "terminal_access" ON products         FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON inventory        FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON cashiers         FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON sales            FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON sale_items       FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON inventory_deltas FOR ALL TO authenticated USING (true);
CREATE POLICY "terminal_access" ON write_conflicts  FOR ALL TO authenticated USING (true);
