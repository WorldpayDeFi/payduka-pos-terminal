// supabase/functions/sync-upload/index.ts
// Handles PowerSync upload queue with conflict resolution strategies 4, 5, 7

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const { batch } = await req.json();

    for (const op of batch) {
      const { op: opType, table, id, data } = op;

      // ── STRATEGY 7: Inventory deltas (insertOnly) ──────────────
      if (table === "inventory_deltas" && opType === "PUT") {
        await supabase.rpc("apply_inventory_delta", {
          p_product_id: data.product_id,
          p_delta:      data.delta,
        });
        continue;
      }

      // ── STRATEGY 4: Sales are immutable once confirmed ──────────
      if (table === "sales" && opType === "PATCH") {
        const { data: existing } = await supabase
          .from("sales")
          .select("status")
          .eq("id", id)
          .single();

        if (existing?.status === "confirmed" && data.status === "pending") {
          // Log as conflict (Strategy 5) instead of applying
          await supabase.from("write_conflicts").insert({
            table_name:    "sales",
            row_id:        id,
            conflict_type: "immutable_status_revert",
            client_data:   data,
            server_data:   existing,
            cashier_id:    data.cashier_id,
          });
          continue;
        }
      }

      // ── Standard CRUD ───────────────────────────────────────────
      if (opType === "PUT") {
        const { error } = await supabase.from(table).upsert({ id, ...data });
        if (error) await logConflict(table, id, "upsert_error", data, null, data.cashier_id);
      }

      if (opType === "PATCH") {
        const { error } = await supabase.from(table).update(data).eq("id", id);
        if (error) await logConflict(table, id, "update_error", data, null, data.cashier_id);
      }

      if (opType === "DELETE") {
        await supabase.from(table).delete().eq("id", id);
      }
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[sync-upload] Error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});

// ── Strategy 5: Log unresolvable conflicts ──────────────
async function logConflict(table, rowId, type, clientData, serverData, cashierId) {
  await supabase.from("write_conflicts").insert({
    table_name:    table,
    row_id:        rowId,
    conflict_type: type,
    client_data:   clientData,
    server_data:   serverData,
    cashier_id:    cashierId,
  });
}
